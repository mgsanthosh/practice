package com.example.mySpringBootWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBootWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
