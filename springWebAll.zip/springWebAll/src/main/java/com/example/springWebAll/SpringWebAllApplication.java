package com.example.springWebAll;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebAllApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebAllApplication.class, args);
	}

}
